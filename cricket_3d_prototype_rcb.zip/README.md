# Cricket 3D Prototype - RCB

Vite + React + TypeScript prototype using three.js (@react-three/fiber).

How to run locally:
1. npm install
2. npm run dev
Open the displayed URL (http://localhost:5173)

Upload the folder to Vercel (Import → Upload zip) and choose the Vite preset to deploy.
